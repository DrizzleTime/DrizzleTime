<script setup>
import {themeStore} from "@/stores/themeStore";

const theme = themeStore();
const toggleTheme = () => {
  theme.switchTheme();
};
</script>

<template>
  <v-app-bar>
    <v-app-bar-title>
      首页
    </v-app-bar-title>
    <v-spacer></v-spacer>
    <v-btn @click="toggleTheme">
      <v-icon>{{ theme.getTheme() === 'dark' ? 'mdi-weather-sunny' : 'mdi-weather-night' }}</v-icon>
    </v-btn>
  </v-app-bar>
</template>

<style scoped>

</style>
