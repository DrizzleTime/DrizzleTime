<template>
  <v-navigation-drawer
    v-model="layout.drawer"
    :rail="layout.getRail()"
    permanent
    @click="layout.setRail(false)"
  >
    <!-- 用户信息 -->
    <v-list-item :prepend-avatar="user.avatar" nav>
      <template v-slot:append>
        <v-btn
          icon="mdi-chevron-left"
          variant="text"
          @click.stop="layout.switchRail()"
        ></v-btn>
      </template>
      <v-list-item-title>{{ user.name }}</v-list-item-title>
      <v-list-item-subtitle>{{ user.subtitle }}</v-list-item-subtitle>
    </v-list-item>

    <v-divider></v-divider>

    <!-- 导航列表 -->
    <v-list density="compact" nav>
      <!-- 循环渲染导航菜单 -->
      <template v-for="(item, index) in menuItems" :key="index">
        <!-- 顶级菜单 -->
        <v-list-item
          v-if="!item.children || item.children.length === 0"
          :prepend-icon="item.icon"
          :title="item.title"
          :to="item.to"
          :color="item.color"
        ></v-list-item>

        <!-- 菜单组 -->
        <v-list-group v-else :value="item.title">
          <template v-slot:activator="{ props }">
            <v-list-item
              v-bind="props"
              :prepend-icon="item.icon"
              :title="item.title"
            ></v-list-item>
          </template>
          <!-- 子菜单 -->
          <v-list-item
            v-for="(child, idx) in item.children"
            :key="idx"
            :title="child.title"
            :to="child.to"
            :color="child.color"
          ></v-list-item>
        </v-list-group>
      </template>
    </v-list>
  </v-navigation-drawer>
</template>

<script setup>
import {layoutStore} from "@/stores/LayoutStore";
import {ref} from 'vue';

const layout = layoutStore();

// 用户信息
const user = ref({
  name: 'John Doe',
  subtitle: 'Admin',
  avatar: 'https://randomuser.me/api/portraits/men/85.jpg',
});
// 导航菜单数据
const menuItems = ref([
  {
    title: '仪表盘',
    icon: 'mdi-view-dashboard',
    to: '/',
    color: 'primary'
  },
  {
    title: '用户管理',
    icon: 'mdi-account-group',
    children: [
      {
        title: '用户列表',
        to: '/user',
        color: 'primary'
      },
      {
        title: '用户权限',
        to: '/user-permissions',
        color: 'primary'
      },
    ]
  },
  {
    title: '内容中心',
    icon: 'mdi-folder-multiple',
    children: [

      {
        title: '内容模块',
        to: '/content/module',
        color: 'primary'
      },
      {
        title: '内容栏目',
        to: '/content/category',
        color: 'primary'
      },
      {
        title: '内容管理',
        to: '/content/management',
        color: 'primary'
      },
    ]
  },
]);

</script>
