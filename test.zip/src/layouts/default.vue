<template>
  <v-theme-provider :theme="theme.getTheme()" with-background>
    <v-layout class="rounded rounded-md">
      <navigation></navigation>
      <top-bar></top-bar>
      <v-main height="100vh" style="background-color: #F0F3FA">
        <div style="margin: 18px;">
          <router-view></router-view>
        </div>
      </v-main>
    </v-layout>
  </v-theme-provider>
</template>
<script setup>
import Navigation from "@/layouts/widgets/navigation.vue";
import {themeStore} from "@/stores/themeStore";
import TopBar from "@/layouts/widgets/topBar.vue";

const theme = themeStore();
</script>
