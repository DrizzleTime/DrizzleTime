// 布局状态
import {defineStore} from 'pinia'

export const layoutStore = defineStore('layout', {
  state: () => ({
    drawer: true,
    rail: false,
  }), actions: {
    getDrawer() {
      return this.drawer
    },
    getRail() {
      return this.rail
    },
    switchDrawer() {
      this.drawer = !this.drawer
    },
    switchRail() {
      this.rail = !this.rail
    },
    setDrawer(value) {
      this.drawer = value
    },
    setRail(value) {
      this.rail = value
    }
  }
})
