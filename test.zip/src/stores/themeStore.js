// 主题状态
import {defineStore} from 'pinia'

export const themeStore = defineStore('theme', {
  state: () => ({
    theme: 'light',
  }), actions: {
    getTheme() {
      return this.theme
    }, switchTheme() {
      this.theme = this.theme === 'light' ? 'dark' : 'light'
    }
  }
})
